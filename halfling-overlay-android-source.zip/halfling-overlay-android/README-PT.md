# A Minha Halfling — Android overlay (protótipo)

Este é o projeto-fonte de uma aplicação Android que tenta mostrar a halfling 3D numa janela flutuante, por cima de outras aplicações. **Não é ainda um APK pronto**: o APK é produzido pelo workflow GitHub Actions incluído.

## Como compilar usando apenas o telemóvel

1. Cria/abre uma conta GitHub no Chrome do Android.
2. Cria um repositório novo chamado `halfling-companion` e define-o como **Public** (necessário para o caminho simples do workflow).
3. No GitHub, usa **Add file → Upload files** para enviar os ficheiros deste projeto extraídos do ZIP, mantendo a estrutura de pastas. Se o GitHub móvel não permitir enviar uma pasta inteira, usa a opção de site para computador ou um gestor de ficheiros que consiga selecionar os ficheiros e pastas.
4. Confirma que `.github/workflows/build-apk.yml` está no repositório e que `app/src/main/assets/companion.html` existe.
5. Abre **Actions → Build Halfling Companion APK → Run workflow** (ou espera pelo build automático após o commit).
6. Quando o workflow ficar verde, abre a execução, desce até **Artifacts** e descarrega `halfling-companion-debug-apk`. Extrai o ZIP do artefacto e instala `app-debug.apk`.
7. Se o Android bloquear a instalação, permite temporariamente **Instalar apps desconhecidas** para o navegador/gestor de ficheiros que usaste.
8. Abre a app, permite **Mostrar por cima de outras apps** e toca em **Mostrar a halfling**.

## Limitações conhecidas do protótipo

- Requer internet para Three.js e para o modelo GLB.
- O URL do modelo configurado é `https://dalvenorwu.netlify.app/halfling_animada.glb`; confirma que esse ficheiro está publicado nesse caminho no Netlify.
- As animações são escolhidas por correspondência parcial de nomes. Se os nomes no GLB forem diferentes, o botão pode selecionar uma animação alternativa.
- A janela flutuante e o WebView podem comportar-se de forma diferente conforme a marca/versão do Android; é necessário testar no dispositivo.
- Este APK é de depuração, não uma versão assinada para publicação na Play Store.
