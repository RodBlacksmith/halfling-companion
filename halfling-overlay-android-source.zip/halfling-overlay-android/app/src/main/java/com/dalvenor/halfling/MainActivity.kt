package com.dalvenor.halfling

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.view.Gravity
import android.graphics.Color

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 28, 28, 28)
            setBackgroundColor(Color.rgb(18, 29, 25))
        }
        val title = TextView(this).apply {
            text = "A Minha Halfling\n\nCompanheira virtual flutuante"
            textSize = 24f
            setTextColor(Color.rgb(244, 220, 157))
            gravity = Gravity.CENTER
        }
        val info = TextView(this).apply {
            text = "Autoriza a sobreposição de ecrã para a personagem aparecer por cima das outras aplicações. Precisa de internet para carregar o modelo 3D."
            textSize = 16f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 24)
        }
        val permission = Button(this).apply {
            text = "1 · Autorizar sobreposição"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                } else startOverlay()
            }
        }
        val start = Button(this).apply {
            text = "2 · Mostrar a halfling"
            setOnClickListener {
                if (Settings.canDrawOverlays(this@MainActivity)) startOverlay()
                else startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
        }
        val stop = Button(this).apply {
            text = "Esconder personagem"
            setOnClickListener { stopService(Intent(this@MainActivity, OverlayService::class.java)) }
        }
        layout.addView(title); layout.addView(info); layout.addView(permission); layout.addView(start); layout.addView(stop)
        setContentView(layout)
    }
    private fun startOverlay() {
        val intent = Intent(this, OverlayService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent)
        finish()
    }
}
